﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ProgPoePart3.Data;
using ProgPoePart3.Models;

namespace ProgPoePart3.Pages.Semesters
{
    public class IndexModel : PageModel
    {
        private readonly ProgPoePart3.Data.ApplicationDbContext _context;

        public IndexModel(ProgPoePart3.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<Semester> Semester { get;set; }

        public async Task OnGetAsync()
        {
            Semester = await _context.Semester.ToListAsync();
        }
    }
}
