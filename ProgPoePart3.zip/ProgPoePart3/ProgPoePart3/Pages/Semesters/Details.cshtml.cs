﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ProgPoePart3.Data;
using ProgPoePart3.Models;

namespace ProgPoePart3.Pages.Semesters
{
    public class DetailsModel : PageModel
    {
        private readonly ProgPoePart3.Data.ApplicationDbContext _context;

        public DetailsModel(ProgPoePart3.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public Semester Semester { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Semester = await _context.Semester.FirstOrDefaultAsync(m => m.courseId == id);

            if (Semester == null)
            {
                return NotFound();
            }
            return Page();
        }
    }
}
