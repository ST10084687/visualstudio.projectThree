﻿using ClassBlog.Models;
using ClassBlog.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClassBlog.Controllers
{
    public class SweetsController : Controller
    {
        // plugins && inheritance
        // with the necessary using statements 

        // access data --> list --> db
        // variables --> allow access 

        private readonly ISweetRepository _sweetRepository;
        private readonly ICategoryRepository _categoryRepository;

        // gets and sets OR ctor
        public SweetsController(ISweetRepository sweetRepository, ICategoryRepository categoryRepository)
        {
            _sweetRepository = sweetRepository;
            _categoryRepository = categoryRepository;
        }

        // action method 
        // ViewResult OR ActionResult 
        public IActionResult List()
        {
            // has to return a view 
            // return View(_sweetRepository.GetAllSweets);
            // consume the listviewModel -->.netcore
            var sweetListViewModel = new SweetListViewModel();
            sweetListViewModel.Sweets = _sweetRepository.GetAllSweets;
            sweetListViewModel.CurrentCateogry = "Tester";
            return View(sweetListViewModel);

        }
        public IActionResult Details(int id)
        {
            var sweet = _sweetRepository.GetSweetById(id);
            if (sweet == null)
                return NotFound();

            return View(sweet);
        }


    }
}
