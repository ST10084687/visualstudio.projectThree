﻿using ClassBlog.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClassBlog.Controllers
{
    public class CategoryController : Controller
    {
        //plugins && inheritance
        //with the necessary using statements

        //acess --> list --> db
        //variables --> allow access

        private readonly ISweetRepository _sweetRepository;
        private readonly ICategoryRepository _categoryRepository;

        //gets and sets --> constructor
        public CategoryController(ISweetRepository sweetRepository, ICategoryRepository categoryRepository)
        {
            _sweetRepository = sweetRepository;
            _categoryRepository = categoryRepository;
        }

        //action method
        //ViewResult or ActionResult
        public ViewResult List()
        {
            //has to return a view
            return View(_categoryRepository.GetAllCategories);
        }
    }
}