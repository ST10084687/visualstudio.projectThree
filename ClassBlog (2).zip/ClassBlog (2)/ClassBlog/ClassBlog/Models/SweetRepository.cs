﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClassBlog.Models
{
    public class SweetRepository : ISweetRepository
    {
        //variable to deal with the categories 
        private readonly AppDbContext _appDbContext;

        //ctor
        public SweetRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        //use some of the properties 


        public IEnumerable<Sweet> GetAllSweets
        {
            get
            {
                return _appDbContext.Sweets.Include(s => s.Category);
            }
        }


        public IEnumerable<Sweet> GetSweetsOnSale

        {
            get
            {
                return _appDbContext.Sweets.Include(s => s.Category).Where(c => c.IsOnSale);
            }
        }

        public Sweet GetSweetById(int sweetId)
        {
            return _appDbContext.Sweets.FirstOrDefault (s => s.sweetId == sweetId);

        }
    }
}
