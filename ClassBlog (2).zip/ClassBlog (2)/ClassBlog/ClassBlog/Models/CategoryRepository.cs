﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClassBlog.Models
{
    public class CategoryRepository : ICategoryRepository
    {
        // must implement the interface 
        // want to rather generate a list of items

        // implements the AppDbContext

        // pvt readonly variable
        private readonly AppDbContext _appDbContext;

        // ctor
        public CategoryRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public IEnumerable<Category> GetAllCategories => _appDbContext.Categories;

        //public IEnumerable<Category> GetAllCategories => new List<Category>
        //{
        //    new Category {CategoryId = 1, CategoryName ="Candy",CategoryDescription="Heavy Sugar"},
        //     new Category {CategoryId = 2, CategoryName ="Chocs",CategoryDescription=" More Sugar"},
        //      new Category {CategoryId = 3, CategoryName ="Liquorice",CategoryDescription="No Sugar"}
        //};
    }
}
