﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClassBlog.Models
{
    public interface ISweetRepository
    {
        IEnumerable<Sweet> GetAllSweets { get; }
        IEnumerable<Sweet> GetSweetsOnSale { get; }
        //how --> ID
        Sweet GetSweetById(int sweetId);

    }
}
