﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ClassBlog.Migrations
{
    public partial class thirdMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Sweets",
                columns: new[] { "sweetId", "CategoryId", "Description", "ImageThumbnailUrl", "ImageUrl", "IsInStock", "IsOnSale", "Name", "Price" },
                values: new object[] { 1, 1, "Crazy Sweets", "\\Images\\gummyCandy.jpg", "\\Images\\gummyCandy.jpg", true, true, "Minions", 8.99m });

            migrationBuilder.InsertData(
                table: "Sweets",
                columns: new[] { "sweetId", "CategoryId", "Description", "ImageThumbnailUrl", "ImageUrl", "IsInStock", "IsOnSale", "Name", "Price" },
                values: new object[] { 2, 2, "Fruity Sweets", "\\Images\\FruitCandy.jpg", "\\Images\\FruitCandy.jpg", true, true, "FruitCandies", 7.99m });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Sweets",
                keyColumn: "sweetId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Sweets",
                keyColumn: "sweetId",
                keyValue: 2);
        }
    }
}
