﻿using ClassBlog.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClassBlog.ViewModels
{
    public class SweetListViewModel
    {
        // fetch all sweets
        // current category 
        public IEnumerable <Sweet> Sweets{ get; set; }
        public string CurrentCateogry { get; set; }
        //can be used to pass objects into views
        // also part of the action result --> view result
        // viewbag --> html tags 
    }
}
