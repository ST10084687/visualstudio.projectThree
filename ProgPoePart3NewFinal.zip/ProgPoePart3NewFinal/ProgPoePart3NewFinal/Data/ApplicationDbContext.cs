﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using ProgPoePart3NewFinal.Models;

namespace ProgPoePart3NewFinal.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<ProgPoePart3NewFinal.Models.Semester> Semester { get; set; }
        public DbSet<ProgPoePart3NewFinal.Models.Reminder> Reminder { get; set; }
    }
}
