﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ProgPoePart3NewFinal.Data;
using ProgPoePart3NewFinal.Models;

namespace ProgPoePart3NewFinal.Pages.Reminders
{
    public class DeleteModel : PageModel
    {
        private readonly ProgPoePart3NewFinal.Data.ApplicationDbContext _context;

        public DeleteModel(ProgPoePart3NewFinal.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Reminder Reminder { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Reminder = await _context.Reminder.FirstOrDefaultAsync(m => m.reminderCourseId == id);

            if (Reminder == null)
            {
                return NotFound();
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Reminder = await _context.Reminder.FindAsync(id);

            if (Reminder != null)
            {
                _context.Reminder.Remove(Reminder);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
