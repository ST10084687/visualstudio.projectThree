﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ProgPoePart3NewFinal.Data;
using ProgPoePart3NewFinal.Models;

namespace ProgPoePart3NewFinal.Pages.Reminders
{
    public class IndexModel : PageModel
    {
        private readonly ProgPoePart3NewFinal.Data.ApplicationDbContext _context;

        public IndexModel(ProgPoePart3NewFinal.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<Reminder> Reminder { get;set; }

        public async Task OnGetAsync()
        {
            Reminder = await _context.Reminder.ToListAsync();
        }
    }
}
