﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using ProgPoePart3NewFinal.Data;
using ProgPoePart3NewFinal.Models;

namespace ProgPoePart3NewFinal.Pages.Reminders
{
    public class CreateModel : PageModel
    {
        private readonly ProgPoePart3NewFinal.Data.ApplicationDbContext _context;

        public CreateModel(ProgPoePart3NewFinal.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public Reminder Reminder { get; set; }

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Reminder.Add(Reminder);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
