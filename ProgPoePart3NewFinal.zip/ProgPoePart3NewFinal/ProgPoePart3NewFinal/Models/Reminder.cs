﻿using ProgPoeDll;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using static ProgPoeDll.Class1;

namespace ProgPoePart3NewFinal.Models
{
    public class Reminder
    {
        //use of dll
        courseInformation information = new courseInformation();
        //courseInformation information = new courseInformation();
        List<courseInformation> informationList = new List<courseInformation>();

        Class1 cl = new Class1();

        [Key]
        public int reminderCourseId { get; set; }
        public string reminderCourseName { get; set; }
        public string reminderCourseCode { get; set; }
   
  


        public DateTime reminderDate { get; set; }
        //public int month { get; set; }
    }
}
