﻿//using ProgPoeDll;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
//using static ProgPoeDll.Class1;

namespace LinqEFWpf
{
    /// <summary>
    /// Interaction logic for SemesterInformation.xaml
    /// </summary>
    public partial class SemesterInformation : Window
    {
        //courseInformation information = new courseInformation();
        //courseInformation information = new courseInformation();
       // List<courseInformation> informationList = new List<courseInformation>();

       // Class1 cl = new Class1();

        public SemesterInformation()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            UserInformation information = new UserInformation();
            information.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {






        }

        private void DataGrid2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {

            Persons1Entities1 db = new Persons1Entities1();
            Semester semesterObject = new Semester()



            // confirm if entry is correct before sending to the DGV

            {
                //pull info from the boxes 

                // semesterInput temp = new semesterInput();

                //temp.day = Convert.ToInt32(dayTB.Text);
                //temp.month = Convert.ToInt32(monthTB.Text);
                //temp.name = courseTB.Text;
                //temp.hoursWorked = Convert.ToInt32(hoursTB.Text);
                //temp.startDate = Convert.ToDateTime(dateTB.Text);


                //DataGrid2.Items.Add(temp);

                day = Convert.ToInt32(dayTB.Text),
                month = Convert.ToInt32(monthTB.Text),

                name = courseTB.Text,
                hoursWorked = Convert.ToInt32(hoursTB.Text),
                startDate = Convert.ToDateTime(dateTB.Text)



            };

            //MessageBox.Show("Is the entry correct? ",
            //   "Confirm Entry", MessageBoxButton.YesNo)
            //   == MessageBoxResult.Yes) ;



            db.Semesters.Add(semesterObject);

            db.SaveChanges();

        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            dayTB.Clear();
            monthTB.Clear();
            courseTB.Clear();
            hoursTB.Clear();


        }

        //private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        //{

        //}
        private void Button_Click_8(object sender, RoutedEventArgs e)
        {



            //if (MessageBox.Show("Is the entry correct? ",
            //   "Confirm Entry", MessageBoxButton.YesNo)
            //   == MessageBoxResult.Yes)
            //{



            //    information.courseName = tbCourseName.Text;
            //    information.courseCode = tbCourseCode.Text;
            //    information.credits = Convert.ToInt32(tbCredits.Text);
            //    information.classHours = Convert.ToInt32(tbHours.Text);
            //    information.semesterWeeks = Convert.ToInt32(tbWeeks.Text);
            //    information.selfStudyHoursPerWeek = cl.selfStudyHoursCalculation(Convert.ToInt32(tbCredits.Text), Convert.ToInt32(tbWeeks.Text), Convert.ToInt32(tbHours.Text));
            //    information.hoursRemaining = cl.hoursCalc(information.selfStudyHoursPerWeek, Convert.ToInt32(tbHours.Text));

            //    DataGrid1.Items.Add(information);



            //}


        }
        private void Button_Click_9(object sender, RoutedEventArgs e)
        {
            tbCourseName.Clear();
            tbCourseCode.Clear();
            tbCredits.Clear();
            tbHours.Clear();
            tbWeeks.Clear();
        }
        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            //if (MessageBox.Show("The information will be arranged in ascending order? ",
            //   "Confirm Entry", MessageBoxButton.YesNo)
            //   == MessageBoxResult.Yes)
            //{

            //    {
            //        var sorted =
            //        from information in informationList
            //        orderby information.courseName
            //        select information.courseName;

            //        foreach (var element in sorted)
            //        {
            //            DataGrid1.Items.Add(element);
            //        }
            //    }

            //}
        }
        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
