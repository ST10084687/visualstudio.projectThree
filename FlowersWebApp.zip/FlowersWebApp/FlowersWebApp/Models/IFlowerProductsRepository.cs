﻿using System.Collections.Generic;

namespace FlowersWebApp.Models
{
    public interface IFlowerProductsRepository
    {
        // search --> id 
        // get all products
        // // sale?

        IEnumerable<FlowerProducts> GetAllFlowerProducts { get; }
        IEnumerable<FlowerProducts> GetFlowerProductsOnSale { get; }
        FlowerProducts GetFlowerProductsById(int FlowerProductsId);
        

    }
}
