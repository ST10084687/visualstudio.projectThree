﻿using System.Collections.Generic;

namespace FlowersWebApp.Models
{
    public interface IFlowerProductsCategoriesRepository
    {
        IEnumerable<FlowerProductsCategories> GetAllCategories { get; }
    }
}
