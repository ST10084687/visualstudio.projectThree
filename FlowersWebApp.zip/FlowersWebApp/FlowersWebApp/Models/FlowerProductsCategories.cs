﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FlowersWebApp.Models
{
    public class FlowerProductsCategories
    {
        [Key]
        //id / name / description
        public int FlowerProductsCategoryId { get; set; }
        public string FlowerProductsCategoryName { get; set; }
        public string FlowerProductsCategoryDescription { get; set; }

        //link to products
        public List<FlowerProducts> FlowerProducts { get; set; }
    }
}
