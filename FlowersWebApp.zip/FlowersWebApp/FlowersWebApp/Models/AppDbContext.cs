﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;

namespace FlowersWebApp.Models
{
    //works with.net EF
    public class AppDbContext : IdentityDbContext<IdentityUser>
    {
        //Inherit from base dbcontext class

        public AppDbContext(DbContextOptions<AppDbContext> options) :
            base(options)
        { }
            public DbSet<FlowerProducts> FlowerProducts { get; set; }
        public DbSet<FlowerProductsCategories> FlowerProductsCategories { get; set; }


        //seeding 
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            //category
            modelBuilder.Entity<FlowerProductsCategories>().HasData(new FlowerProductsCategories { FlowerProductsCategoryId = 1, FlowerProductsCategoryName = "Flowers", FlowerProductsCategoryDescription = "Bouquets are the best kinds of floral gifts for her because they're easy to hold and look rather charming in any kind of flower vase." });


            modelBuilder.Entity<FlowerProducts>().HasData(new FlowerProducts {
                FlowerProductsId = 1,
                Name = "Sunflower",
                Description = "They are bright and cheery, and as warm and inviting as the sweet summer sun. ",
                FlowerProductsCategoryId = 1,
                Price = 255,
                ImageUrl = "https://cdn.atwilltech.com/flowerdatabase/s/sunflower-power-bouquet-arrangement-62745e2f721133.03800938.425.jpg",
                ImageThumbnailUrl = "https://cdn.atwilltech.com/flowerdatabase/s/sunflower-power-bouquet-arrangement-62745e2f721133.03800938.425.jpg",
                IsInStock = true,
                IsOnSale = true });

            modelBuilder.Entity<FlowerProducts>().HasData(new FlowerProducts
            {
                FlowerProductsId = 2,
                Name = "Red Roses",
                Description = "Bright ruby red roses are the true sign of love and usually symbolize passion, desire, and romance. ",
                FlowerProductsCategoryId = 1,
                Price = 255,
                ImageUrl = "https://www.royal-flowers.dp.ua/image/cache/catalog/Bouquet/box%20hat/51-krasnaya-roza-sort-prestizh-v-korobke-royal-flowers%20-720x720.jpg",
                ImageThumbnailUrl = "https://www.royal-flowers.dp.ua/image/cache/catalog/Bouquet/box%20hat/51-krasnaya-roza-sort-prestizh-v-korobke-royal-flowers%20-720x720.jpg",
                IsInStock = true,
                IsOnSale = true
            });

            modelBuilder.Entity<FlowerProducts>().HasData(new FlowerProducts
            {
                FlowerProductsId = 3,
                Name = "Kadupul Flower",
                Description = "The Kadupul Flower is a cactus blossom that rarely blooms, and is therefore considered as one of the rare flowers in the world. Not only that, but it also blooms only at night and withers away by daybreak. ",
                FlowerProductsCategoryId = 1,
                Price = 255,
                ImageUrl = "https://d2rdhxfof4qmbb.cloudfront.net/wp-content/uploads/20200604131516/Kadupul-flowers.jpg",
                ImageThumbnailUrl = "https://d2rdhxfof4qmbb.cloudfront.net/wp-content/uploads/20200604131516/Kadupul-flowers.jpg",
                IsInStock = true,
                IsOnSale = true
                
            
            });

            }




    }
}
