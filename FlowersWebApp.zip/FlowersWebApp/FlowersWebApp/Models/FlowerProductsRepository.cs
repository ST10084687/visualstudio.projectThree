﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace FlowersWebApp.Models
{
    public class FlowerProductsRepository : IFlowerProductsRepository
    {

        //private readonly IFlowerProductsCategoriesRepository _flowerProductsCategoriesRepository = new FlowerProductsCategoriesRepository();
        private readonly AppDbContext _appDbContext;

        public FlowerProductsRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public IEnumerable<FlowerProducts> GetFlowerProducts
        {
            get
            {
                return _appDbContext.FlowerProducts.Include(p => p.FlowerProductsCategories);
            }
        }
        public IEnumerable<FlowerProducts> GetFlowerProductsOnSale
        {
            get
            {
                return _appDbContext.FlowerProducts.Include(p => p.FlowerProductsCategories).Where(p => p.IsOnSale);
            }
        }



        public IEnumerable<FlowerProducts> GetAllFlowerProducts => _appDbContext.FlowerProducts;
        //{
        //    get
        //    {
        //        return _appDbContext.FlowerProducts.Include(p => p.FlowerProductsCategories);
        //    }
        //}


        //implement the interface 
        //using statements
        //public IEnumerable<FlowerProducts> GetAllFlowerProducts => new List<FlowerProducts>
        //{
        //    new FlowerProducts{FlowerProductsId = 1, Name ="Sunflower", Description ="They are bright and cheery, and as warm and inviting as the sweet summer sun. ", Price=255,
        //        ImageUrl="https://cdn.atwilltech.com/flowerdatabase/s/sunflower-power-bouquet-arrangement-62745e2f721133.03800938.425.jpg",
        //       ImageThumbnailUrl="https://cdn.atwilltech.com/flowerdatabase/s/sunflower-power-bouquet-arrangement-62745e2f721133.03800938.425.jpg",
        //       IsInStock=true, IsOnSale=true, FlowerProductsCategories = _flowerProductsCategoriesRepository.GetAllCategories.ToList()[0]},
        //     new FlowerProducts{FlowerProductsId = 2, Name ="Red Roses", Description ="Bright ruby red roses are the true sign of love and usually symbolize passion, desire, and romance. ", Price=255,
        //        ImageUrl="https://www.royal-flowers.dp.ua/image/cache/catalog/Bouquet/box%20hat/51-krasnaya-roza-sort-prestizh-v-korobke-royal-flowers%20-720x720.jpg",
        //       ImageThumbnailUrl="https://www.royal-flowers.dp.ua/image/cache/catalog/Bouquet/box%20hat/51-krasnaya-roza-sort-prestizh-v-korobke-royal-flowers%20-720x720.jpg",
        //       IsInStock=true, IsOnSale=true, FlowerProductsCategories = _flowerProductsCategoriesRepository.GetAllCategories.ToList()[1]},
        //      new FlowerProducts{FlowerProductsId = 1, Name ="Kadupul Flower", Description ="The Kadupul Flower is a cactus blossom that rarely blooms, and is therefore considered as one of the rare flowers in the world. Not only that, but it also blooms only at night and withers away by daybreak. ", Price=255,
        //        ImageUrl="https://d2rdhxfof4qmbb.cloudfront.net/wp-content/uploads/20200604131516/Kadupul-flowers.jpg",
        //       ImageThumbnailUrl="https://d2rdhxfof4qmbb.cloudfront.net/wp-content/uploads/20200604131516/Kadupul-flowers.jpg",
        //       IsInStock=true, IsOnSale=true, FlowerProductsCategories = _flowerProductsCategoriesRepository.GetAllCategories.ToList()[2]},
        //};


        public FlowerProducts GetFlowerProductsById(int FlowerProductsId)
        {
            return GetAllFlowerProducts.FirstOrDefault(P => P.FlowerProductsId == FlowerProductsId);
        }
    }
}
