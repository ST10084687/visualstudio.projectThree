﻿using System.Collections.Generic;

namespace FlowersWebApp.Models
{
    public class FlowerProductsCategoriesRepository : IFlowerProductsCategoriesRepository
    {
        //variables
        private readonly AppDbContext _appDbContext;


        //Constructor
        public FlowerProductsCategoriesRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public IEnumerable<FlowerProductsCategories> GetAllCategories => _appDbContext.FlowerProductsCategories;



        //public IEnumerable<FlowerProductsCategories> GetAllCategories => new List<FlowerProductsCategories>
        //{
        //    new FlowerProductsCategories {FlowerProductsCategoryId = 1, FlowerProductsCategoryName="Flowers", FlowerProductsCategoryDescription = "Bouquets are the best kinds of floral gifts for her because they're easy to hold and look rather charming in any kind of flower vase." },
        //    new FlowerProductsCategories {FlowerProductsCategoryId = 2, FlowerProductsCategoryName="Potpourri", FlowerProductsCategoryDescription = "Potpourri can be just as pretty as flowers, and it's a good way to turn the flowers into a keepsake." },
        //    new FlowerProductsCategories {FlowerProductsCategoryId = 3, FlowerProductsCategoryName="Pressed flower cards", FlowerProductsCategoryDescription = "Press the flowers onto some cards for greeting cards that are easy to make yet elegant. You can use them as thank-you or special-occasion cards." }

        //};
    }
}
