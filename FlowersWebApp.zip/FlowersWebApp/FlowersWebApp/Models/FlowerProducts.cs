﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FlowersWebApp.Models
{
    public class FlowerProducts
    {
        [Key]
        public int FlowerProductsId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int FlowerProductsCategoryId { get; set; }
        public decimal Price { get; set; }
        public string ImageUrl { get; set; }
        public string ImageThumbnailUrl { get; set; }
        public bool IsOnSale { get; set; }
        public bool IsInStock { get; set; }


        //link to flower category

        [ForeignKey("FlowerProductsCategoryId")]
        public FlowerProductsCategories FlowerProductsCategories { get; set; }
    }
    
}
