﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FlowersWebApp.Migrations
{
    public partial class testLaunch2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
