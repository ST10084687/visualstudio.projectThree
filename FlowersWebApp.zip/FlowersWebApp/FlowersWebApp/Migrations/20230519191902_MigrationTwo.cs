﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FlowersWebApp.Migrations
{
    public partial class MigrationTwo : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "FlowerProductsCategories",
                columns: table => new
                {
                    FlowerProductsCategoryId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FlowerProductsCategoryName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FlowerProductsCategoryDescription = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FlowerProductsCategories", x => x.FlowerProductsCategoryId);
                });

            migrationBuilder.CreateTable(
                name: "FlowerProducts",
                columns: table => new
                {
                    FlowerProductsId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Price = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    ImageUrl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ImageThumbnailUrl = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsOnSale = table.Column<bool>(type: "bit", nullable: false),
                    IsInStock = table.Column<bool>(type: "bit", nullable: false),
                    FlowerProductsCategoriesFlowerProductsCategoryId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FlowerProducts", x => x.FlowerProductsId);
                    table.ForeignKey(
                        name: "FK_FlowerProducts_FlowerProductsCategories_FlowerProductsCategoriesFlowerProductsCategoryId",
                        column: x => x.FlowerProductsCategoriesFlowerProductsCategoryId,
                        principalTable: "FlowerProductsCategories",
                        principalColumn: "FlowerProductsCategoryId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_FlowerProducts_FlowerProductsCategoriesFlowerProductsCategoryId",
                table: "FlowerProducts",
                column: "FlowerProductsCategoriesFlowerProductsCategoryId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "FlowerProducts");

            migrationBuilder.DropTable(
                name: "FlowerProductsCategories");
        }
    }
}
