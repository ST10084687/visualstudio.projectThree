﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FlowersWebApp.Migrations
{
    public partial class migrationThree : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "FlowerProductsCategories",
                columns: new[] { "FlowerProductsCategoryId", "FlowerProductsCategoryDescription", "FlowerProductsCategoryName" },
                values: new object[] { 1, "Bouquets are the best kinds of floral gifts for her because they're easy to hold and look rather charming in any kind of flower vase.", "Flowers" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "FlowerProductsCategories",
                keyColumn: "FlowerProductsCategoryId",
                keyValue: 1);
        }
    }
}
