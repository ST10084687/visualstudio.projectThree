﻿using FlowersWebApp.Models;
using Microsoft.AspNetCore.Mvc;

namespace FlowersWebApp.Controllers
{
    public class FlowerProductsController : Controller
    {
        //using mvc
        //to fetch data --> repos --> access fields
        // read only variables --> Ienumable

        private readonly IFlowerProductsRepository _flowerProductsRepository;
        private readonly IFlowerProductsCategoriesRepository _flowerProductsCategoriesRepository;

        public FlowerProductsController(IFlowerProductsRepository flowerProductsRepository, IFlowerProductsCategoriesRepository flowerProductsCategoriesRepository)
        {
            _flowerProductsRepository = flowerProductsRepository;
            _flowerProductsCategoriesRepository = flowerProductsCategoriesRepository;
        }
        // action method --> ViewResult --> ActionResult
        public ViewResult List()
        {
            return View(_flowerProductsRepository.GetAllFlowerProducts);
        }
    }
}
