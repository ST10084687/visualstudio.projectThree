﻿using FlowersWebApp.Models;
using Microsoft.AspNetCore.Mvc;

namespace FlowersWebApp.Controllers
{
    public class FlowerProductsCategoriesController : Controller
    {
        //using mvc
        //to fetch data --> repos --> access fields
        // read only variables --> Ienumable

        private readonly IFlowerProductsRepository _flowerProductsRepository;
        private readonly IFlowerProductsCategoriesRepository _flowerProductsCategoriesRepository;

        public FlowerProductsCategoriesController(IFlowerProductsRepository flowerProductsRepository, IFlowerProductsCategoriesRepository flowerProductsCategoriesRepository)
        {
            _flowerProductsRepository = flowerProductsRepository;
            _flowerProductsCategoriesRepository = flowerProductsCategoriesRepository;
        }


        // action method --> ViewResult --> ActionResult
        public ViewResult List()
        {
            return View(_flowerProductsCategoriesRepository.GetAllCategories);
        }
    }
}
