using FlowersWebApp.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
//using static System.Collections.Immutable.ImmutableArray<T>;

namespace FlowersWebApp
{

    public class Startup
    {
       
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        
        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //generate the db
            services.AddDbContext<AppDbContext>(options =>
            options.UseSqlServer(Configuration.GetConnectionString
            ("DefaultConnection")));
            //service tag for identity
            services.AddDefaultIdentity<IdentityUser>()
                .AddRoles<IdentityRole>()
                .AddEntityFrameworkStores<AppDbContext>();


            services.AddControllersWithViews();
            //implement the services --> categories / products 
            services.AddScoped<IFlowerProductsCategoriesRepository, FlowerProductsCategoriesRepository>();
            services.AddScoped<IFlowerProductsRepository, FlowerProductsRepository>();

            services.AddSession();
            services.AddRazorPages();
        }
        
        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }
            app.UseHttpsRedirection();
            app.UseStaticFiles();
            //app.UseSession();
            app.UseRouting();
            //razor pages

            app.UseAuthorization();

            _ = app.UseEndpoints(async endpoints =>
              {
                  endpoints.MapControllerRoute(
                      name: "default",
                      pattern: "{controller=Home}/{action=Index}/{id?}");
                  endpoints.MapRazorPages();
                  using (var scope = app.ApplicationServices.CreateScope())
                  {
                      var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();

                      var roles = new[] { "Farmer", "Employee" };

                      foreach (var role in roles)
                      {
                          if (!await roleManager.RoleExistsAsync(role))
                              await roleManager.CreateAsync(new IdentityRole(role));
                      }
                  }

                  using (var scope = app.ApplicationServices.CreateScope())
                  {
                      var userManager = scope.ServiceProvider.GetRequiredService<UserManager<IdentityUser>>();

                      string email = "employee@gmail.com";
                      string passsword = "Employee1234";
                      if (await userManager.FindByEmailAsync(email) == null)
                      {
                          
                          var user = new IdentityUser();
                          user.UserName = email;
                          user.Email = email;
                          user.Id = user.Id;
                        // user.EmailConfirmed = true;

                        await userManager.CreateAsync(user, passsword);

                          await userManager.AddToRoleAsync(user, "Employee");
                        // await userManager.AddToRoleAsync(passsword, "Employee");

                    }
                  }
              });
        }
    }
}
