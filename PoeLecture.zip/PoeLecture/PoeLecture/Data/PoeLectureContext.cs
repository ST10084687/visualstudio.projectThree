﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PoeLecture.Models;

namespace PoeLecture.Data
{
    public class PoeLectureContext : DbContext
    {
        public PoeLectureContext (DbContextOptions<PoeLectureContext> options)
            : base(options)

        {
        }

        public DbSet<PoeLecture.Models.Movie> Movie { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)

        {

            modelBuilder.Entity<PoeLecture.Models.Movie>()

                .Property(p => p.Vat)

                .HasComputedColumnSql("[Price]*115/100");

        }


        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    modelBuilder.Entity<PoeLecture.Models.Movie>().
        //        Property(p => p.VAT)

        //        .HasComputedColumnSql("[Price]*115/100");
        //}
    }
}
