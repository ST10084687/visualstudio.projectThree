﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Bin.Demo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //global object decleration
        Student s = new Student();

        public MainWindow()
        {
            InitializeComponent();
            //load when program loads
            s.StudentName = "John";
            s.Surname = "Smith";
            s.StudentNumber = 99999;
            s.Age = 19;
            //create a data context
            this.DataContext = s; //source

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //details to show up
            string message = "\nStudent name: " + s.StudentName
                + "\nStudent Surname: " + s.Surname
                + "\nStudent Number: " + s.StudentNumber
                + "\nStudent Age: " + s.Age;

            //passs this into a message box
            MessageBox.Show("============================="
                +message
                + "\n=============================\n");
        }
    }
}
